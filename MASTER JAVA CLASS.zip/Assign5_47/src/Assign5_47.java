/*
 
  @author tp0719561
 */
public class Assign5_47 
{


    public static void main(String[] args) 
    {
        
        String isbn;
        isbn = "1234";
        int sum = 0;
        
        int k = isbn.charAt(3) -48;
        System.out.println(k);
        sum+=k;
        
    }
    
}



/*
    @author tp0719561
 */
import java.util.Scanner;
public class Exam1HandOn 
{

   
    public static void main(String[] args) 
    {
        Scanner ScannerObject = new Scanner(System.in); 
        String stringInput;
        String newString;
    
        System.out.print("Enter a string: ");
        stringInput = ScannerObject.nextLine();    
    
        newString = swapCase(stringInput);
    
     //System.out.print("The new string is "+ newString);
        
    }
    
    public static String swapCase(String s)
    {
        int length;
        length = s.length();
       // System.out.println(length);
        String stringOutput;
        char lowerS=0;
        char upperS=0;
       
        for(int i=0; i < length; i++)
        {
            
          
           
           
           
           
        
           
            if(lowerS != upperS)
            {
              lowerS = s.charAt(i);
            lowerS = Character.toUpperCase(lowerS);
            //s.replace(upperS, lowerS);
            
            
            System.out.print(lowerS);
            
            }
            else
            {
              //s.toUpperCase();
            upperS = s.charAt(i);
                
            upperS = Character.toLowerCase(upperS);
          
           
             //s.replace(lowerS, upperS);
            System.out.print(upperS);
            }
        }
                
        
        
        //System.out.println( stringOutput);
        return s;
    }
    
}



/**
 *
 * @author tp0719561
 */
public class Test 
{

    
    public static void main(String[] args) 
    {
        int[] values = new int[5];
        
        //Test(values)
            
        //for(int i=1;i<5;i++)
       // {
           // values[i]=i+values[i-1];
        
           // System.out.println(java.util.Arrays.toString(values));
        
       // }
        //values[0]=values[1]+ values[4];
        //System.out.println(java.util.Arrays.toString(values));
        
        /*
        java.util.Scanner input = new java.util.Scanner(System.in);
       // System.out.print("Enter "+values.length+ " values: ");
        for(int i = 0; i < values.length; i++)
        {
        values[i] = (int) (Math.random() * 100);
            //values[i]= input.nextInt();
        int sumValues=0;
        
        sumValues = values[i] + values[i];
        
            System.out.print(values[i]+ " ");
            System.out.println("Sum of the integers"+ sumValues);
        }
        
        double max =values[0];
        for (int i = 1; i< values.length; i++)
        {
        
            if(values[i]> max) max = values[i];
            {
            
                                
                
            }
            
            
        }
                */
    }
   
    /*
    public static  Test (values[])
    {
    
        for(int i= 0; i < values.length -1; i++)
        {
        
            
        
        }
    
    }
    */
}



/**
 *
 * @author tp0719561
 */
public class Assign5_49 
{

  
    public static void main(String[] args) 
    {
    
    }
    
}

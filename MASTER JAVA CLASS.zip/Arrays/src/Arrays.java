
/**
 *
 * @author tp0719561
 */
public class Arrays 
{

    
    public static void main(String[] args) 
    {
        String[] myList = new String[10];
        
        myList[0] = " _-*-_ ";
        
        myList[1] = " _-*-_ ";
        
        myList[2] = " _-*-_ ";
        
        myList[3] = " _-*-_ ";
        
        myList[4] = " _-*-_ ";
        
        myList[5] = " _-*-_ ";
        
        myList[6] = " _-*-_ ";
        
        myList[7] = " _-*-_ ";
        
        myList[8] = " _-*-_ ";
        
        myList[9] = " _-*-_ ";
        
        //myList[10] = " ** ";
        
        System.out.println(java.util.Arrays.toString(myList));
        
        myList[1] = " _*-*_ ";
        
        
        
        
        System.out.println(java.util.Arrays.toString(myList));
        
        myList[2] = " _*-*-*_ ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[3] = " *-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[4] = " *-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[5] = " *-*-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));
        
        myList[6] = " *-*-*-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[7] = " *-*-*-*-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[8] = " *-*-*-*-*-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

        myList[9] = " *-*-*-*-*-*-*-*-*-* ";
        
        System.out.println(java.util.Arrays.toString(myList));

      
        
        //System.out.println(java.util.Arrays.toString(myList));

    }
    
}
